package com.example.moviedbapp;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;

public class SimpleItemTouchHelperCallback extends ItemTouchHelper.Callback {

    private final WatchlistAdapter mAdapter;
    private Context mContext;

    public SimpleItemTouchHelperCallback(WatchlistAdapter adapter, Context context) {
        mAdapter = adapter;
        mContext = context;
    }

    @Override
    public boolean isLongPressDragEnabled() {
        return true;
    }

    @Override
    public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
        int dragFlags = ItemTouchHelper.UP | ItemTouchHelper.DOWN | ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT;
        return makeMovementFlags(dragFlags, 0);
    }

    @Override
    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target)
    {
        int start_pos = viewHolder.getAdapterPosition();
        int target_pos = target.getAdapterPosition();

        SharedPreferences sharedPreferences = mContext.getSharedPreferences("memory", Context.MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        try{
            JSONArray watchlist_data =  new JSONArray(sharedPreferences.getString("watchlist", ""));
            JSONObject temp = watchlist_data.getJSONObject(start_pos);

            if(start_pos < target_pos)
            {
                for(int i = start_pos; i<target_pos; i++)
                {
                    mAdapter.swap(i, i+1);
                    watchlist_data.put(i, watchlist_data.getJSONObject(i+1));
                }
                watchlist_data.put(target_pos, temp);
            }
            else if (start_pos > target_pos)
            {
                for(int i = start_pos; i>target_pos; i--)
                {
                    mAdapter.swap(i, i-1);
                    watchlist_data.put(i, watchlist_data.getJSONObject(i-1));
                }
                watchlist_data.put(target_pos, temp);
            }
            myEdit.putString("watchlist", watchlist_data.toString());
            myEdit.commit();
        }
        catch(JSONException e){}

        return true;
    }

    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
    }

}