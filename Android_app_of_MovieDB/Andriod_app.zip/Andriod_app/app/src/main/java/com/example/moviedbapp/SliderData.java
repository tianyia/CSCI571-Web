package com.example.moviedbapp;

public class SliderData {

    // image url is used to
    // store the url of image
    private String imgUrl;
    private String type;
    private String id;

    // Constructor method.
    public SliderData(String imgUrl, String type, String id) {
        this.imgUrl = imgUrl;
        this.type = type;
        this.id = id;
    }

    // Getter method
    public String getImgUrl() {
        return imgUrl;
    }
    public String gettype() {
        return type;
    }
    public String getid() {
        return id;
    }

    // Setter method
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
