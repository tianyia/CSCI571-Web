package com.example.moviedbapp;

import org.json.JSONException;
import org.json.JSONObject;

public class search_data {
    private JSONObject data;

    public search_data(JSONObject data)
    {
        this.data = data;
    }

    public String getsrc()
    {
        String result = "";
        try{
            result = data.getString("backdrop_path");
        }
        catch(JSONException e){}
        return result;
    }
    public String gettype()
    {
        String result = "";
        try{
            result = data.getString("type");
        }
        catch(JSONException e){}
        return result;
    }
    public String gettime()
    {
        String result = "";
        try{
            result = data.getString("release_date");
        }
        catch(JSONException e){}
        return result;
    }
    public String getrating()
    {
        String result = "";
        try{
            if(data.getString("rating") != null && data.getString("rating") != "")
            {
                result = data.getString("rating");
            }
            else
            {
                result = "0";
            }
        }
        catch(JSONException e){}
        return result;
    }
    public String gettitle()
    {
        String result = "";
        try{
            result = data.getString("title");
        }
        catch(JSONException e){}
        return result;
    }
    public String getid()
    {
        String result = "";
        try{
            result = data.getString("id");
        }
        catch(JSONException e){}
        return result;
    }
}
