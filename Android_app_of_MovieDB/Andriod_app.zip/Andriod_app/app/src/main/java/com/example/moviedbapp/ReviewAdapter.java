package com.example.moviedbapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ReviewViewHolder> {

    private Context mContext;
    private ArrayList<review_data> data;

    public ReviewAdapter(Context mContext, ArrayList<review_data> data) {
        this.mContext = mContext;
        this.data = data;
    }


    @NonNull
    @Override
    public ReviewAdapter.ReviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.detail_review_item, parent, false);

        return new ReviewAdapter.ReviewViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull ReviewAdapter.ReviewViewHolder holder, int position) {

        holder.author.setText(
                "by " + data.get(position).getauthor() + " on " + data.get(position).gettime()
        );
        holder.rating.setText(
                String.valueOf(Float.parseFloat(data.get(position).getrating())/2.0) + "/5"
        );
        holder.content.setText(
                data.get(position).getcontent()
        );
        holder.star.setColorFilter(Color.parseColor("#ffd700"));

    }

    public class ReviewViewHolder extends RecyclerView.ViewHolder {

        private TextView author;
        private TextView rating;
        private TextView content;
        private ImageView star;

        private CardView clickable;

        public ReviewViewHolder(View view) {
            super(view);
            // Define click listener and find view here

            author = view.findViewById(R.id.detail_review_author);
            rating = view.findViewById(R.id.detail_review_rating);
            content = view.findViewById(R.id.detail_review_content);
            star = view.findViewById(R.id.star);

            clickable = view.findViewById(R.id.detail_review_clickable);

            clickable.setOnClickListener(v -> {
                Intent reviewactivity = new Intent(mContext, MainActivity3_ReviewPage.class);
                reviewactivity.putExtra("author", data.get(getAdapterPosition()).getauthor());
                reviewactivity.putExtra("time", data.get(getAdapterPosition()).gettime());
                reviewactivity.putExtra("rating", data.get(getAdapterPosition()).getrating());
                reviewactivity.putExtra("content", data.get(getAdapterPosition()).getcontent());
                mContext.startActivity(reviewactivity);
            });

        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
