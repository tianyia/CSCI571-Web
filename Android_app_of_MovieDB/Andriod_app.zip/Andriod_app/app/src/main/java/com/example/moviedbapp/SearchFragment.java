package com.example.moviedbapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SearchFragment extends Fragment {

    private SearchFragment mContext = SearchFragment.this;

    private JSONArray returned_data;

    private boolean first_flag = true;

    private ArrayList<search_data> search_adapter_data = new ArrayList<>();
    private SearchAdapter searchAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View Search_Page_view = inflater.inflate(R.layout.fragment_search, container, false);

        SearchView searchbar = Search_Page_view.findViewById(R.id.search_bar);

        TextView not_found = Search_Page_view.findViewById(R.id.search_not_found);

        searchbar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if(newText.length() >= 1)
                {
                    //volley request
                    String url = "http://moviedbandroidserverbytianyian-env.eba-khpg3mej.us-east-2.elasticbeanstalk.com/apis/search/" + newText;
                    JsonArrayRequest jsonArrayRequest = new JsonArrayRequest
                            (Request.Method.GET, url, null, new Response.Listener<JSONArray>() {

                                @Override
                                public void onResponse(JSONArray response) {
                                    try{
                                        search_adapter_data.clear();
                                        for(int i=0; i< Math.min(20, response.length()); i++)
                                        {
                                            search_adapter_data.add(new search_data(response.getJSONObject(i)));
                                        }
                                        if(first_flag)
                                        {
                                            first_set(Search_Page_view);
                                        }
                                        else
                                        {
                                            searchAdapter.notifyDataSetChanged();
                                        }
                                        if(response.length() == 0)
                                        {
                                            not_found.setVisibility(Search_Page_view.VISIBLE);
                                        }
                                        else
                                        {
                                            not_found.setVisibility(Search_Page_view.GONE);
                                        }
                                    }
                                    catch(JSONException e){}
                                }
                            }, new Response.ErrorListener() {

                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    System.out.println("home http fail?");
                                }
                            });

                    // Instantiate the RequestQueue.
                    RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
                    queue.add(jsonArrayRequest);
                }
                else
                {
                    search_adapter_data.clear();
                    searchAdapter.notifyDataSetChanged();
                }
                return false;
            }
        });

        return Search_Page_view;
    }

    public void first_set(View search_view)
    {
        RecyclerView search_recycle_view = search_view.findViewById(R.id.search_result_recyclerview);
        searchAdapter = new SearchAdapter(SearchFragment.this, search_adapter_data);
        search_recycle_view.setItemAnimator(new DefaultItemAnimator());
        search_recycle_view.setAdapter(searchAdapter);
        first_flag = false;
    }
}
