package com.example.moviedbapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Collections;

public class WatchlistAdapter extends RecyclerView.Adapter<WatchlistAdapter.WatchlistViewHolder>{

    private Context mContext;
    private ArrayList<RecycleData> data;
    private TextView no_data;

    public WatchlistAdapter(Context mContext, ArrayList<RecycleData> data, TextView no_data) {
        this.mContext = mContext;
        this.data = data;
        this.no_data = no_data;
    }


    @NonNull
    @Override
    public WatchlistAdapter.WatchlistViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.watchlist_item, parent, false);

        return new WatchlistAdapter.WatchlistViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull WatchlistAdapter.WatchlistViewHolder holder, int position) {

        String src = data.get(position).getSrc();
        Picasso.get().load("https://image.tmdb.org/t/p/original/" + src).into(holder.watchlist_image);
        holder.type.setText(data.get(position).gettype());
//        if(data.size() == 0)
//        {
//            holder.no_data.setVisibility(View.VISIBLE);
//        }
//        else
//        {
//            holder.no_data.setVisibility(View.GONE);
//        }
    }

    public class WatchlistViewHolder extends RecyclerView.ViewHolder {

        private ImageView watchlist_image;
        private TextView type;
        private ImageView remove_button;

        public WatchlistViewHolder(View view) {
            super(view);
            // Define click listener and find view here

            watchlist_image = view.findViewById(R.id.watchlist_image);
            type = view.findViewById(R.id.watchlist_type);
            remove_button = view.findViewById(R.id.watchlist_remove_button);

            watchlist_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent detailactivity = new Intent(v.getContext(), MainActivity2_DetailPage.class);
                    detailactivity.putExtra("type", data.get(getAdapterPosition()).gettype());
                    detailactivity.putExtra("id", data.get(getAdapterPosition()).getid());
                    v.getContext().startActivity(detailactivity);
                }
            });

            remove_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences sharedPreferences = v.getContext().getSharedPreferences("memory", Context.MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = sharedPreferences.edit();
                    try{
                        JSONArray watchlist_data = new JSONArray(sharedPreferences.getString("watchlist", ""));

                        //delete from watchlist
                        watchlist_data.remove(getAdapterPosition());
                        myEdit.putString("watchlist", watchlist_data.toString());
                        myEdit.commit();
                        Toast.makeText(v.getContext(), data.get(getAdapterPosition()).gettitle() + " was removed from Watchlist", Toast.LENGTH_SHORT).show();

                        data.remove(getAdapterPosition());
//                        data.clear();
//                        for(int k=0; k<watchlist_data.length(); k++)
//                        {
//                            data.add(new RecycleData(
//                                    watchlist_data.getJSONObject(k).getString("src"),
//                                    watchlist_data.getJSONObject(k).getString("id"),
//                                    watchlist_data.getJSONObject(k).getString("type"),
//                                    watchlist_data.getJSONObject(k).getString("title")
//                            ));
//                        }
                        if(data.size() == 0)
                        {
                            no_data.setVisibility(View.VISIBLE);
                        }
                        notifyDataSetChanged();
                    }
                    catch(JSONException e){}
                }
            });

        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void swap(int start, int end)
    {
        Collections.swap(data, start, end);
        notifyItemMoved(start, end);
    }
}
