package com.example.moviedbapp;

import org.json.JSONException;
import org.json.JSONObject;

public class review_data {
    private JSONObject data;

    public review_data(JSONObject data)
    {
        this.data = data;
    }

    public String getauthor()
    {
        String result = "";
        try{
            result = data.getString("author");
        }
        catch(JSONException e){}
        return result;
    }
    public String getcontent()
    {
        String result = "";
        try{
            result = data.getString("content");
        }
        catch(JSONException e){}
        return result;
    }
    public String gettime()
    {
        String result = "";
        try{
            result = data.getString("created_at");
        }
        catch(JSONException e){}
        return result;
    }
    public String getrating()
    {
        String result = "0";
        try{
            if(data.getString("rating") != null && data.getString("rating") != "")
            {
                result = data.getString("rating");
            }
        }
        catch(JSONException e){}
        return result;
    }
}
