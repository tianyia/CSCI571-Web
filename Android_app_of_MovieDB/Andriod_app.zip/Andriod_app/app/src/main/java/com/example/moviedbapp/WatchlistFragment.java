package com.example.moviedbapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class WatchlistFragment extends Fragment {

    private ArrayList<RecycleData> adapter_data = new ArrayList<>();
    private WatchlistAdapter watchlistAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View watchlist_page_view = inflater.inflate(R.layout.fragment_watchlist, container, false);

        Context mContext = getActivity();
        RecyclerView watchlist_grid = watchlist_page_view.findViewById(R.id.watchlist_page_grid);
        watchlist_grid.setLayoutManager(new GridLayoutManager(mContext, 3));

        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("memory", Context.MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sharedPreferences.edit();
        TextView no_item = watchlist_page_view.findViewById(R.id.watchlist_not_found);

        try{
            JSONArray watchlist_data = new JSONArray(sharedPreferences.getString("watchlist", ""));
            if(watchlist_data.length() == 0)
            {
                no_item.setVisibility(watchlist_page_view.VISIBLE);
            }
            else
            {
                no_item.setVisibility(watchlist_page_view.GONE);
                for(int i=0; i<watchlist_data.length(); i++)
                {
                    adapter_data.add(new RecycleData(
                            watchlist_data.getJSONObject(i).getString("src"),
                            watchlist_data.getJSONObject(i).getString("id"),
                            watchlist_data.getJSONObject(i).getString("type"),
                            watchlist_data.getJSONObject(i).getString("title")
                    ));
                }
                watchlistAdapter = new WatchlistAdapter(getActivity(), adapter_data, no_item);
                watchlist_grid.setAdapter(watchlistAdapter);
            }
        }
        catch(JSONException e){}

        ItemTouchHelper.Callback callback = new SimpleItemTouchHelperCallback(watchlistAdapter, getActivity());
        ItemTouchHelper helper = new ItemTouchHelper(callback);
        helper.attachToRecyclerView(watchlist_grid);

        return watchlist_page_view;
    }
}
