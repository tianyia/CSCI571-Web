package com.example.moviedbapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.toolbox.Volley;
import com.smarteist.autoimageslider.SliderView;
import java.util.ArrayList;


import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.RequestQueue;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

public class HomeFragment extends Fragment {

    private TextView Movies_tab;
    private TextView TV_Shows_tab;
    private JSONArray cur_movie;
    private JSONArray pop_movie;
    private JSONArray top_movie;
    private JSONArray trend_tv;
    private JSONArray pop_tv;
    private JSONArray top_tv;

    private ArrayList<SliderData> sliderDataArrayList = new ArrayList<>();
    private SliderAdapter adapter;
    private ArrayList<RecycleData> data_list1 = new ArrayList<>();
    private RecycleAdapter adapter1;
    private ArrayList<RecycleData> data_list2 = new ArrayList<>();
    private RecycleAdapter adapter2;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View home_view = inflater.inflate(R.layout.fragment_home, container, false);

        ArrayList<SliderData> sliderDataArrayList = new ArrayList<>();

        RelativeLayout home_spinner =home_view.findViewById(R.id.home_progress_bar);
        home_spinner.setVisibility(View.VISIBLE);

        //volley request
        String url = "http://moviedbandroidserverbytianyian-env.eba-khpg3mej.us-east-2.elasticbeanstalk.com/apis/";
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try{
                            cur_movie = response.getJSONArray("cur_movie");
                            pop_movie = response.getJSONArray("pop_movie");
                            top_movie = response.getJSONArray("top_movie");
                            trend_tv = response.getJSONArray("trend_tv");
                            pop_tv = response.getJSONArray("pop_tv");
                            top_tv = response.getJSONArray("top_tv");

                            setData(home_view, cur_movie, top_movie, pop_movie);

                            firstset(home_view);

                            home_spinner.setVisibility(home_view.GONE);

                        }
                        catch(JSONException e){}
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("home http fail?");
                    }
                });

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        queue.add(jsonObjectRequest);


        Movies_tab = home_view.findViewById(R.id.Movies_tab);
        TV_Shows_tab = home_view.findViewById(R.id.TV_Shows_tab);
        Movies_tab.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Movies_tab.setTextColor(getResources().getColor(R.color.colorPrimary));
                        TV_Shows_tab.setTextColor(getResources().getColor(R.color.white));
                        setData(home_view, cur_movie, top_movie, pop_movie);
                        adapter.notifyDataSetChanged();
                        adapter1.notifyDataSetChanged();
                        adapter2.notifyDataSetChanged();
                    }
                }
        );
        TV_Shows_tab.setOnClickListener(
                v -> {
                    Movies_tab.setTextColor(getResources().getColor(R.color.white));
                    TV_Shows_tab.setTextColor(getResources().getColor(R.color.colorPrimary));
                    setData(home_view, trend_tv, top_tv, pop_tv);
                    adapter.notifyDataSetChanged();
                    adapter1.notifyDataSetChanged();
                    adapter2.notifyDataSetChanged();
                }
        );

        TextView TMDB_link = home_view.findViewById(R.id.TMDB_link);
        TMDB_link.setOnClickListener(v -> {
            Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.themoviedb.org/"));
            getActivity().startActivity(browser);
        });

        return home_view;
    }

    public void setData(View home_view, JSONArray data, JSONArray data1, JSONArray data2) {
        try{
            // we are creating array list for storing our image urls.
            sliderDataArrayList.clear();
            data_list1.clear();
            data_list2.clear();

            for(int i=0; i<6; i++)
            {
                sliderDataArrayList.add(new SliderData(
                        "https://image.tmdb.org/t/p/original/" + data.getJSONObject(i).getString("poster_path"),
                        data.getJSONObject(i).getString("type"),
                        data.getJSONObject(i).getString("id")
                        )
                );
            }
            for (int i = 0; i < 10; i++)
            {
                data_list1.add(new RecycleData(
                        data1.getJSONObject(i).getString("poster_path"),
                        data1.getJSONObject(i).getString("id"),
                        data1.getJSONObject(i).getString("type"),
                        data1.getJSONObject(i).getString("title")
                        ));
                data_list2.add(new RecycleData(
                        data2.getJSONObject(i).getString("poster_path"),
                        data2.getJSONObject(i).getString("id"),
                        data2.getJSONObject(i).getString("type"),
                        data2.getJSONObject(i).getString("title")
                        ));
            }
        }
        catch(JSONException e){}
    }

    public void firstset(View home_view)
    {

        // passing this array list inside our adapter class.
        adapter = new SliderAdapter(HomeFragment.this, sliderDataArrayList);

        // initializing the slider view.
        SliderView sliderView = home_view.findViewById(R.id.slider);
        // below method is used to set auto cycle direction in left to
        // right direction you can change according to requirement.
        sliderView.setAutoCycleDirection(SliderView.LAYOUT_DIRECTION_LTR);

        // below method is used to
        // setadapter to sliderview.
        sliderView.setSliderAdapter(adapter);

        // below method is use to set
        // scroll time in seconds.
        sliderView.setScrollTimeInSec(3);

        // to set it scrollable automatically
        // we use below method.
        sliderView.setAutoCycle(true);

        // to start autocycle below method is used.
        sliderView.startAutoCycle();


        RecyclerView target_view = home_view.findViewById(R.id.top_rated_content);
        adapter1 = new RecycleAdapter(data_list1, getActivity());
        target_view.setItemAnimator(new DefaultItemAnimator());
        target_view.setAdapter(adapter1);
        RecyclerView target_view2 = home_view.findViewById(R.id.popular_content);
        adapter2 = new RecycleAdapter(data_list2, getActivity());
        target_view2.setItemAnimator(new DefaultItemAnimator());
        target_view2.setAdapter(adapter2);
    }
}
