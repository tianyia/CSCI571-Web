package com.example.moviedbapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.widget.Toast;

import androidx.appcompat.widget.PopupMenu;
import androidx.recyclerview.widget.RecyclerView;


import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

// The adapter class which
// extends RecyclerView Adapter
public class RecycleAdapter
        extends RecyclerView.Adapter<RecycleAdapter.LinearViewHolder> {

    private ArrayList<RecycleData> media_list;
    private Context mContext;

    public RecycleAdapter(ArrayList<RecycleData> dataSet, Context context) {
        media_list = dataSet;
        mContext = context;
    }
    /**
     * Provide a reference to the type of views that you are using
     * (custom ViewHolder).
     */
    public class LinearViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener, PopupMenu.OnMenuItemClickListener{
        private final ImageView poster;
        private ImageView button;
        private boolean to_add;

        public LinearViewHolder(View view) {
            super(view);
            // Define click listener for the ViewHolder's View

            poster = view.findViewById(R.id.home_recycler_view_image);
            button = view.findViewById(R.id.home_recycler_view_button);

            button.setOnClickListener(this);
            poster.setOnClickListener(v -> {
                Intent detailactivity = new Intent(mContext, MainActivity2_DetailPage.class);
                detailactivity.putExtra("type", media_list.get(getAdapterPosition()).gettype());
                detailactivity.putExtra("id", media_list.get(getAdapterPosition()).getid());
                mContext.startActivity(detailactivity);
            });
        }

        @Override
        public void onClick(View v) {
            showpopupmenu(v);
        }

        private void showpopupmenu(View view)
        {
            PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
            popupMenu.inflate(R.menu.popup_menu);

            popupMenu.setOnMenuItemClickListener(this);

            SharedPreferences sharedPreferences = mContext.getSharedPreferences("memory", Context.MODE_PRIVATE);
            JSONArray watchlist_data = new JSONArray();
            to_add = true;
            if(sharedPreferences.contains("watchlist"))
            {
                try{
                    watchlist_data = new JSONArray(sharedPreferences.getString("watchlist", ""));
                    for(int i=0; i<watchlist_data.length(); i++)
                    {
                        if(watchlist_data.getJSONObject(i).getString("type").equals(media_list.get(getAdapterPosition()).gettype())
                                && watchlist_data.getJSONObject(i).getString("id").equals(media_list.get(getAdapterPosition()).getid()))
                        {
                            to_add = false;
                        }
                    }
                }
                catch(JSONException e){}
            }

            Log.d("康康内存", String.valueOf(watchlist_data.length()));
            Log.d("康康旗子", String.valueOf(to_add));
            if(!to_add)
            {
                popupMenu.getMenu().getItem(3).setTitle("Remove from Watchlist");
            }

            popupMenu.show();
        }

        @Override
        public boolean onMenuItemClick(MenuItem item) {
            switch (item.getItemId())
            {
                case R.id.popup_TMDB:
                    Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.themoviedb.org/" +
                            media_list.get(getAdapterPosition()).gettype() + "/" +
                            media_list.get(getAdapterPosition()).getid()));
                    mContext.startActivity(browser);
                    return true;
                case R.id.popup_Facebook:
                    Intent browser1 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/sharer/sharer.php?u=" +
                            "https://www.themoviedb.org/" +
                            media_list.get(getAdapterPosition()).gettype() + "/" +
                            media_list.get(getAdapterPosition()).getid()));
                    mContext.startActivity(browser1);
                    return true;
                case R.id.popup_Twitter:
                    Intent browser2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/intent/tweet?text=Check%20this%20out!%0D%0A" +
                            "https://www.themoviedb.org/" +
                            media_list.get(getAdapterPosition()).gettype() + "/" +
                            media_list.get(getAdapterPosition()).getid()));
                        mContext.startActivity(browser2);
                    return true;
                case R.id.popup_Watchlist:
                    SharedPreferences sharedPreferences = mContext.getSharedPreferences("memory", Context.MODE_PRIVATE);
                    SharedPreferences.Editor myEdit = sharedPreferences.edit();
                    JSONArray watchlist_data = new JSONArray();

                    if(sharedPreferences.contains("watchlist"))
                    {
                        try{
                            watchlist_data = new JSONArray(sharedPreferences.getString("watchlist", ""));
                            for(int i=0; i<watchlist_data.length(); i++)
                            {
                                if(watchlist_data.getJSONObject(i).getString("type").equals(media_list.get(getAdapterPosition()).gettype())
                                && watchlist_data.getJSONObject(i).getString("id").equals(media_list.get(getAdapterPosition()).getid()))
                                {
                                    //delete from watchlist
                                    watchlist_data.remove(i);
                                    myEdit.putString("watchlist", watchlist_data.toString());
                                    myEdit.commit();

                                    Toast.makeText(mContext, media_list.get(getAdapterPosition()).gettitle() + " was removed from Watchlist", Toast.LENGTH_SHORT).show();
                                    return true;
                                }
                            }
                        }
                        catch(JSONException e){}
                    }

                    JSONObject new_item = new JSONObject();
                    try{
                        new_item.put("id", media_list.get(getAdapterPosition()).getid());
                        new_item.put("type", media_list.get(getAdapterPosition()).gettype());
                        new_item.put("src", media_list.get(getAdapterPosition()).getSrc());
                        new_item.put("title", media_list.get(getAdapterPosition()).gettitle());

                        watchlist_data.put(new_item);
                        myEdit.putString("watchlist", watchlist_data.toString());
                        myEdit.commit();
                    }
                    catch(JSONException e){}

                    Toast.makeText(mContext, media_list.get(getAdapterPosition()).gettitle() + " was added to Watchlist", Toast.LENGTH_SHORT).show();
                    return true;
            }
            return false;
        }
    }

    // Create new views (invoked by the layout manager)
    @Override
    public RecycleAdapter.LinearViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.home_recycler_view_item, parent, false);

        return new LinearViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(RecycleAdapter.LinearViewHolder viewHolder, final int position) {

        // Get element from your dataset at this position and replace the
        // contents of the view with that element
        String src = media_list.get(position).getSrc();
        Picasso.get().load("https://image.tmdb.org/t/p/w500/" + src).into(viewHolder.poster);

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return media_list.size();
    }
}