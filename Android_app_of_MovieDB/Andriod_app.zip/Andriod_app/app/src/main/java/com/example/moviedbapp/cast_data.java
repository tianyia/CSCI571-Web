package com.example.moviedbapp;

public class cast_data {
    private String src;
    private String name;

    public cast_data(String src, String name)
    {
        this.src = src;
        this.name = name;
    }

    public String getSrc()
    {
        return src;
    }
    public String getname()
    {
        return name;
    }
}
