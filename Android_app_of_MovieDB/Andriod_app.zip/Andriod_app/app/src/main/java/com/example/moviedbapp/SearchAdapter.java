package com.example.moviedbapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.SearchViewHolder>{

    private SearchFragment mContext;
    private ArrayList<search_data> data;

    public SearchAdapter(SearchFragment mContext, ArrayList<search_data> data) {
        this.mContext = mContext;
        this.data = data;
    }


    @NonNull
    @Override
    public SearchAdapter.SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.search_result_item, parent, false);

        return new SearchAdapter.SearchViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull SearchAdapter.SearchViewHolder holder, int position) {

        String src = data.get(position).getsrc();
        Picasso.get().load("https://image.tmdb.org/t/p/original/" + src).into(holder.search_image);
        holder.time.setText(data.get(position).gettype() + "(" + data.get(position).gettime().substring(0,4) + ")");
        holder.title.setText(data.get(position).gettitle());
        holder.rating.setText(String.format("%.1f", Float.parseFloat(data.get(position).getrating())/2.0));
        holder.star.setColorFilter(Color.parseColor("#ffd700"));

    }

    public class SearchViewHolder extends RecyclerView.ViewHolder {

        private CardView clickable;
        private ImageView search_image;
        private ImageView star;
        private TextView time;
        private TextView title;
        private TextView rating;

        public SearchViewHolder(View view) {
            super(view);
            // Define click listener and find view here

            clickable = view.findViewById(R.id.search_result_clickable);
            search_image = view.findViewById(R.id.search_result_image);
            star = view.findViewById(R.id.search_result_star);
            time = view.findViewById(R.id.search_result_time);
            title = view.findViewById(R.id.search_result_title);
            rating = view.findViewById(R.id.search_result_rating);

            clickable.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent detailactivity = new Intent(v.getContext(), MainActivity2_DetailPage.class);
                    detailactivity.putExtra("type", data.get(getAdapterPosition()).gettype());
                    detailactivity.putExtra("id", data.get(getAdapterPosition()).getid());
                    v.getContext().startActivity(detailactivity);
                }
            });

        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
