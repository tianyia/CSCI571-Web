package com.example.moviedbapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class MainActivity3_ReviewPage extends AppCompatActivity {

    private String rating_data;
    private String author_data;
    private String time_data;
    private String content_data;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity3_review);

        //get data passed from DetailPage
        Intent myintent = getIntent();
        rating_data = myintent.getStringExtra("rating");
        author_data = myintent.getStringExtra("author");
        time_data = myintent.getStringExtra("time");
        content_data = myintent.getStringExtra("content");

        TextView rating = findViewById(R.id.reviewpage_rating);
        ImageView star = findViewById(R.id.reviewpage_star);
        TextView author = findViewById(R.id.reviewpage_author);
        TextView content = findViewById(R.id.reviewpage_content);

        rating.setText(String.valueOf(Float.parseFloat(rating_data)/2.0) + "/5");
        star.setColorFilter(Color.parseColor("#ffd700"));
        author.setText(
                "by " + author_data + " on " + time_data
        );
        content.setText(content_data);
    }
}
