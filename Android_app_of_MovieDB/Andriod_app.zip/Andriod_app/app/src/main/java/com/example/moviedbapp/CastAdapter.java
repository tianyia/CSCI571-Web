package com.example.moviedbapp;

import android.content.Context;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CastAdapter extends RecyclerView.Adapter<CastAdapter.CastViewHolder> {

    private Context mContext;
    private ArrayList<cast_data> data;

    public CastAdapter(Context mContext, ArrayList<cast_data> data) {
        this.mContext = mContext;
        this.data = data;
    }


    @NonNull
    @Override
    public CastAdapter.CastViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.detail_cast_item, parent, false);

        return new CastViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull CastAdapter.CastViewHolder holder, int position) {

        String src = data.get(position).getSrc();
        Picasso.get().load("https://image.tmdb.org/t/p/w500/" + src).into(holder.cast_image);
        holder.cast_name.setText(data.get(position).getname());

    }

    public class CastViewHolder extends RecyclerView.ViewHolder {

        private ImageView cast_image;
        private TextView cast_name;

        public CastViewHolder(View view) {
            super(view);
            // Define click listener and find view here

            cast_image = view.findViewById(R.id.detail_profile_image);
            cast_name = view.findViewById(R.id.detail_profile_text);

        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }
}
