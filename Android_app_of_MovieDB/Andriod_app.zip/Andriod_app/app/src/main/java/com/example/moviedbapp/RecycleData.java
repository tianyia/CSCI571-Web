package com.example.moviedbapp;

import android.widget.ScrollView;

public class RecycleData {
    private String src;
    private String id;
    private String type;
    private String title;

    public RecycleData(String src, String id, String type, String title)
    {
        this.src = src;
        this.id = id;
        this.type = type;
        this.title = title;
    }

    public String getSrc()
    {
        return src;
    }
    public String getid()
    {
        return id;
    }
    public String gettype()
    {
        return type;
    }
    public String gettitle() {return title;}

    public void setSrc(String src)
    {
        this.src = src;
    }
}
