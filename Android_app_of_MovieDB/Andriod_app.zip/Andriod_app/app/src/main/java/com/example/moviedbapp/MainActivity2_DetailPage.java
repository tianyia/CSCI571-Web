package com.example.moviedbapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.borjabravo.readmoretextview.ReadMoreTextView;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity2_DetailPage extends AppCompatActivity {

    private String type;
    private String id;

    private JSONObject trailer;
    private JSONObject detail;
    private JSONArray review;
    private JSONArray cast;
    private JSONArray recommend;
    private JSONArray similar;

    private ArrayList<RecycleData> data_list = new ArrayList<>();
    private RecycleAdapter adapter;

    private ArrayList<cast_data> cast_data_list = new ArrayList<>();
    private CastAdapter castAdapter;

    private ArrayList<review_data> review_data_list = new ArrayList<>();
    private ReviewAdapter reviewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity2__detail_page);

        //get data passed from home
        Intent myintent = getIntent();
        type = myintent.getStringExtra("type");
        id = myintent.getStringExtra("id");

        RelativeLayout detail_spinner = findViewById(R.id.detail_progress_bar);
        detail_spinner.setVisibility(View.VISIBLE);

        //volley request
        String url = "http://moviedbandroidserverbytianyian-env.eba-khpg3mej.us-east-2.elasticbeanstalk.com/apis/watch/"+type+"/"+id;
        Log.d("康康type",type);
        Log.d("康康id",id);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try{
                            trailer = response.getJSONObject("trailer");
                            detail = response.getJSONObject("detail");
                            review = response.getJSONArray("review");
                            cast = response.getJSONArray("cast");
                            recommend = response.getJSONArray("recommend");
                            similar = response.getJSONArray("similar");

                            YouTubePlayerView youTubePlayerView = findViewById(R.id.youtube_player_view);
                            youTubePlayerView.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
                                @Override
                                public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                                    try{
                                        String videoID = trailer.getString("key");
                                        if (videoID == null || videoID.isEmpty())
                                        {
                                            videoID = "tzkWB85ULJY";
                                        }
                                        youTubePlayer.cueVideo(videoID, 0);
                                    }
                                    catch(JSONException e){}
                                }
                            });

                            TextView detail_title = findViewById(R.id.detail_title);
                            detail_title.setText(detail.getString("title"));
                            ReadMoreTextView detail_overview = findViewById(R.id.detail_overview);
                            detail_overview.setText(detail.getString("overview"));
                            TextView detail_genres = findViewById(R.id.detail_genres);
                            detail_genres.setText(detail.getString("genres"));
                            TextView detail_year = findViewById(R.id.detail_year);
                            detail_year.setText(detail.getString("release_date").substring(0,4));

                            //buttons
                            ImageView button_watchlist = findViewById(R.id.detail_button_watchlist);
                            ImageView button_facebook = findViewById(R.id.detail_button_facebook);
                            ImageView button_twitter = findViewById(R.id.detail_button_twitter);

                            SharedPreferences sharedPreferences = getSharedPreferences("memory", Context.MODE_PRIVATE);
                            JSONArray watchlist_data_initial_check = new JSONArray();
                            if(sharedPreferences.contains("watchlist"))
                            {
                                try{
                                    watchlist_data_initial_check = new JSONArray(sharedPreferences.getString("watchlist", ""));
                                    for(int i=0; i<watchlist_data_initial_check.length(); i++)
                                    {
                                        if(watchlist_data_initial_check.getJSONObject(i).getString("type").equals(type)
                                                && watchlist_data_initial_check.getJSONObject(i).getString("id").equals(id))
                                        {
                                            button_watchlist.setImageResource(R.drawable.ic_baseline_remove_circle_outline_24);
                                        }
                                    }
                                }
                                catch(JSONException e){}
                            }

                            button_watchlist.setOnClickListener(v -> {
                                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                                JSONArray watchlist_data = new JSONArray();

                                boolean should_add = true;
                                if(sharedPreferences.contains("watchlist"))
                                {
                                    try{
                                        watchlist_data = new JSONArray(sharedPreferences.getString("watchlist", ""));
                                        for(int i=0; i<watchlist_data.length(); i++)
                                        {
                                            if(watchlist_data.getJSONObject(i).getString("type").equals(type)
                                                    && watchlist_data.getJSONObject(i).getString("id").equals(id))
                                            {
                                                //delete from watchlist
                                                watchlist_data.remove(i);
                                                myEdit.putString("watchlist", watchlist_data.toString());
                                                myEdit.commit();

                                                Toast.makeText(v.getContext(), detail.getString("title") + " was removed from Watchlist", Toast.LENGTH_SHORT).show();
                                                should_add = false;
                                                button_watchlist.setImageResource(R.drawable.ic_baseline_add_circle_outline_24);
                                            }
                                        }
                                    }
                                    catch(JSONException e){}
                                }

                                if(should_add)
                                {
                                    JSONObject new_item = new JSONObject();
                                    try{
                                        new_item.put("id", id);
                                        new_item.put("type", type);
                                        new_item.put("src", detail.getString("poster_path"));
                                        new_item.put("title", detail.getString("title"));

                                        watchlist_data.put(new_item);
                                        myEdit.putString("watchlist", watchlist_data.toString());
                                        myEdit.commit();

                                        Toast.makeText(v.getContext(), detail.getString("title") + " was added to Watchlist", Toast.LENGTH_SHORT).show();
                                        button_watchlist.setImageResource(R.drawable.ic_baseline_remove_circle_outline_24);
                                    }
                                    catch(JSONException e){}
                                }

                            });
                            button_facebook.setOnClickListener(v -> {
                                Intent browser1 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/sharer/sharer.php?u=" +
                                        "https://www.themoviedb.org/" +
                                        type + "/" + id));
                                startActivity(browser1);
                            });
                            button_twitter.setOnClickListener(v -> {
                                Intent browser2 = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/intent/tweet?text=Check%20this%20out!%0D%0A" +
                                        "https://www.themoviedb.org/" + type + "/" + id));
                                startActivity(browser2);
                            });

                            //cast data
                            RecyclerView cast_grid = findViewById(R.id.cast_grid);
                            cast_grid.setLayoutManager(new GridLayoutManager(MainActivity2_DetailPage.this, 3));

                            for(int i=0; i< Math.min(6, cast.length()); i++)
                            {
                                try{
                                    cast_data_list.add(new cast_data(
                                            cast.getJSONObject(i).getString("profile_path"),
                                            cast.getJSONObject(i).getString("name")
                                    ));
                                }
                                catch(JSONException e){}
                            }

                            castAdapter = new CastAdapter(MainActivity2_DetailPage.this, cast_data_list);
                            cast_grid.setAdapter(castAdapter);

                            //review
                            RecyclerView review_view = findViewById(R.id.review_list);
                            review_view.setLayoutManager(new LinearLayoutManager(MainActivity2_DetailPage.this, LinearLayoutManager.VERTICAL, false));

                            for(int i=0; i<Math.min(3, review.length());i++)
                            {
                                try{
                                    review_data_list.add(new review_data((review.getJSONObject(i))));
                                }
                                catch(JSONException e){}
                            }
                            reviewAdapter = new ReviewAdapter(MainActivity2_DetailPage.this, review_data_list);
                            review_view.setAdapter(reviewAdapter);

                            //recommend data

                            for (int i = 0; i < Math.min(10, recommend.length()); i++)
                            {
                                data_list.add(new RecycleData(
                                        recommend.getJSONObject(i).getString("poster_path"),
                                        recommend.getJSONObject(i).getString("id"),
                                        recommend.getJSONObject(i).getString("type"),
                                        recommend.getJSONObject(i).getString("title")
                                ));
                            }
                            RecyclerView target_view = findViewById(R.id.recommended_content);
                            adapter = new RecycleAdapter(data_list, target_view.getContext());
                            target_view.setItemAnimator(new DefaultItemAnimator());
                            target_view.setAdapter(adapter);


                            TextView detail_text_overview = findViewById(R.id.detail_text_overview);
                            TextView detail_text_genre = findViewById(R.id.detail_text_genres);
                            TextView detail_text_year = findViewById(R.id.detail_text_year);
                            TextView detail_text_cast = findViewById(R.id.detail_text_cast);
                            TextView detail_text_review = findViewById(R.id.detail_text_reviews);
                            TextView detail_text_recommend = findViewById(R.id.detail_text_recommend);
                            if(detail.getString("overview").equals(""))
                            {
                                detail_text_overview.setVisibility(View.GONE);
                            }
                            if(detail.getString("genres").equals(""))
                            {
                                detail_text_genre.setVisibility(View.GONE);
                            }
                            if(detail.getString("release_date").equals(""))
                            {
                                detail_text_year.setVisibility(View.GONE);
                            }
                            if(cast.length() == 0)
                            {
                                detail_text_cast.setVisibility(View.GONE);
                            }
                            if(review.length() == 0)
                            {
                                detail_text_review.setVisibility(View.GONE);
                            }
                            if(recommend.length() == 0)
                            {
                                detail_text_recommend.setVisibility(View.GONE);
                            }

                            detail_spinner.setVisibility(View.GONE);

                        }
                        catch(JSONException e){}
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("detail http fail?");
                    }
                });

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);

        YouTubePlayerView youTubePlayerView = findViewById(R.id.youtube_player_view);
        getLifecycle().addObserver(youTubePlayerView);
    }
}